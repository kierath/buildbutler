Dummy build for the Build Butler demo.
A real build would contain the packaged game here.
